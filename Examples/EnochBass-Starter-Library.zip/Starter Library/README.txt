Starter MIDI library (made by Enoch's own generator).
One folder per genre: 1 Intro, 2 Verse, 3 Solo, 4 Outro - each Sparse, Medium and Hot.
No key-switches, so every file plays on any instrument. Tempo and key are in the file name (transpose freely in your DAW).
Hot solos use 1/32 runs (not in ballads / kizomba). Drag a file into your DAW, or load it in the plugin as a style reference.
